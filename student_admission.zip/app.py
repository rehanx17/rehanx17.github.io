from flask import Flask, render_template, request, make_response
from flask_sqlalchemy import SQLAlchemy
from xhtml2pdf import pisa
import io

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
db = SQLAlchemy(app)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100))
    course = db.Column(db.String(100))

@app.before_first_request
def create_tables():
    db.create_all()

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        course = request.form["course"]
        new_student = Student(name=name, email=email, course=course)
        db.session.add(new_student)
        db.session.commit()
    students = Student.query.all()
    return render_template("index.html", success=(request.method=="POST"), students=students)

@app.route("/export/pdf")
def export_pdf():
    students = Student.query.all()
    html = render_template("pdf_template.html", students=students)
    result = io.BytesIO()
    pisa.CreatePDF(io.StringIO(html), dest=result)
    response = make_response(result.getvalue())
    response.headers["Content-Type"] = "application/pdf"
    response.headers["Content-Disposition"] = "attachment; filename=students.pdf"
    return response

if __name__ == "__main__":
    app.run(debug=True)
