# Student Admission Website

A simple Flask-based web app for student admission. It supports:
- Form submission
- SQLite database storage
- PDF export of student records

## Run Locally

1. Clone the repo:
```bash
git clone https://github.com/yourusername/student_admission.git
cd student_admission
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the app:
```bash
python app.py
```

4. Open `http://localhost:5000` in your browser.
